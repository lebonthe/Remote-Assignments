//
//  File.swift
//  aSimpleApp
//
//  Created by Min Hu on 2024/1/22.
//

import Foundation

struct Colors {
    let red: CGFloat
    let green: CGFloat
    let blue: CGFloat
}

let colors = [
Colors(red: 22/255, green: 15/255, blue: 41/255),
Colors(red: 29/255, green: 61/255, blue: 78/255),
Colors(red: 36/255, green: 106/255, blue: 115/255),
Colors(red: 54/255, green: 143/255, blue: 139/255),
Colors(red: 149/255, green: 183/255, blue: 166/255),
Colors(red: 243/255, green: 223/255, blue: 193/255),
Colors(red: 221/255, green: 190/255, blue: 168/255)
]
