//
//  ViewController.swift
//  aSimpleApp
//
//  Created by Min Hu on 2024/1/22.
//

import UIKit

class ViewController: UIViewController {
    // 顯示句子的 label
    @IBOutlet weak var label: UILabel!
    
    // 跟著背景色改變文字顏色的 button
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 更新背景色、按鈕的文字顏色與 label 文字
        updateUI()
    }
    
    // 按下 button 執行的動作
    @IBAction func changeColorRandomly(_ sender: Any) {
        // 更新背景色、按鈕的文字顏色與 label 文字
        updateUI()
    }
    
    // 更新背景色、按鈕的文字顏色與 label 文字
    func updateUI() {
        // 根據 colors 陣列元素的數量產生隨機整數
        let randomIndexOfColors = Int.random(in: 0...colors.count - 1)
        // 根據隨機整數取用 colors 陣列的顏色
        let color = UIColor(red: colors[randomIndexOfColors].red,
                        green: colors[randomIndexOfColors].green,
                        blue: colors[randomIndexOfColors].blue,
                        alpha: 1)
        // 設定背景色與 button 的文字顏色
        view.backgroundColor = color
        button.tintColor = color
        
        // 根據 texts 陣列元素的數量產生隨機整數，取用句子
        let sentence = texts[Int.random(in: 0...texts.count - 1)]
        // 將句子指派為 label 的文字
        label.text = sentence
    }
    
}

