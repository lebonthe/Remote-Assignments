//
//  Content.swift
//  log-in and sign-up
//
//  Created by Min Hu on 2024/1/29.
//

import Foundation

struct AlertText {
    let title: String
    let message: String    
}

