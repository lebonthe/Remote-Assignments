//
//  ViewController.swift
//  log-in and sign-up
//
//  Created by Min Hu on 2024/1/29.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet var textFields: [UITextField]!
    
    @IBOutlet weak var checkLabel: UILabel!
    
    var logInState: Bool = true
    
    let alertTexts: [AlertText] = [AlertText(title: "Error", message: "Account should not be empty."),
                                   AlertText(title: "Error", message: "Password should not be empty."),
                                   AlertText(title: "Error", message: "Check Password should not be empty."),
                                   AlertText(title: "Error", message: "Login fail"),
                                   AlertText(title: "Error", message: "Signup fail"),
                                   AlertText(title: "Welcome", message: "Signup success "),
                                   AlertText(title: "Welcome Back", message: "Login success ")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        
    }
    
    // 選擇 segmentedControl 的動作
    @IBAction func swichLogInOfSignUp(_ sender: UISegmentedControl) {
        if segmentedControl.selectedSegmentIndex == 0 {
            logInState = true
            checkLabel.textColor = .gray
            textFields[2].isEnabled = false
            textFields[2].backgroundColor = .gray
            textFields[2].text = ""
        } else {
            logInState = false
            checkLabel.textColor = .black
            textFields[2].isEnabled = true
            textFields[2].backgroundColor = .white
        }
    }
    
    // 按下 Button 的動作
    @IBAction func tapButton(_ sender: Any) {
        if logInState == true {
            if textFields[0].text == "" {
                showAlert(pass: alertTexts, index: 0)
            } else if textFields[1].text == "" {
                showAlert(pass: alertTexts, index: 1)
            } else if textFields[0].text == "appworks_school" && textFields[1].text == "1234" {
                showAlert(pass: alertTexts, index: 6)
            } else {
                showAlert(pass: alertTexts, index: 3)
            }
        } else {
            if textFields[0].text == "" {
                showAlert(pass: alertTexts, index: 0)
            } else if textFields[1].text == "" {
                showAlert(pass: alertTexts, index: 1)
            } else if textFields[2].text == "" {
                showAlert(pass: alertTexts, index: 2)
            } else if textFields[1].text == textFields[2].text {
                showAlert(pass: alertTexts, index: 5)
            } else {
                showAlert(pass: alertTexts, index: 4)
            }
        }
    }
        
        // UI 配置
        func setUI() {
            segmentedControl.tintColor = .white
            segmentedControl.selectedSegmentTintColor = .black
            segmentedControl.setTitleTextAttributes([.foregroundColor : UIColor.white], for: .selected)
            segmentedControl.layer.borderColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
            segmentedControl.layer.borderWidth = 1
            segmentedControl.selectedSegmentIndex = 0
            textFields[2].isEnabled = false
            textFields[2].backgroundColor = .gray
            for i in 0...textFields.count - 1 {
                textFields[i].returnKeyType = .next
                textFields[i].delegate = self
            }
            
        }
        // 顯示 alert 視窗
        func showAlert(pass alertTexts: [AlertText], index: Int) {
            let alert = UIAlertController(title: alertTexts[index].title, message: alertTexts[index].message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default)
            alert.addAction(okAction)
            present(alert, animated: true)
        }
}
// 讓 textField 可以填完以後按 Next 就往下一欄填寫
extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if logInState == true {
            if textField == textFields[0] {
                return textFields[1].becomeFirstResponder()
            } else {
                return textField.resignFirstResponder()
            }
        } else {
            if textField == textFields[0] {
                return textFields[1].becomeFirstResponder()
            } else if textField == textFields[1] {
                return textFields[2].becomeFirstResponder()
            } else {
                return textField.resignFirstResponder()
            }
            
        }
    }
}
