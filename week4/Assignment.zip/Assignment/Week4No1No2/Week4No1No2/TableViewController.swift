//
//  TableViewController.swift
//  Week4No1No2
//
//  Created by Min Hu on 2024/2/5.
//

import UIKit

class TableViewController: UITableViewController {

    var backgroundColor: UIColor = .white
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    func composeColor(red: CGFloat, green: CGFloat) -> UIColor {
        var newRed = 1.0
        var newGreen = 1.0
        if red == 0 {
            newRed = 50 / 255
            newGreen = (green * 28) / 255
        } else {
            newRed = 1
            newGreen = (green * 60) / 255
        }
        return UIColor(red: newRed, green: newGreen, blue: 1, alpha: 1)
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        print("numberOfSections")
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        print("numberOfRowsInSection")
        return section == 0 ? 10 : 5
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cellForRowAt")
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableViewCell", for: indexPath)
        var content = cell.defaultContentConfiguration()
        content.text = "This is section \(indexPath.section), row \(indexPath.row)"
        cell.contentConfiguration = content
        cell.backgroundColor = backgroundColor
        return cell
    }
    /** # 題目2：
        因為使用 TableViewController，TableViewController 預設為 TableView 的 dataSource 與 delegate，因此有已經定義好的方法可以覆寫。
     下方的 `didSelectRowAt`在選中一個 row 時，根據該 section 與 row 的值，透過 composeColor 方法組成一個新的背景色。設定完之後，必須使用`tableView.reloadData()`重新載入跟 tableView 相關 section 跟 row 的資料。
         藉由在每個方法中放入 print，在模擬器中運行 app 的同時點選任意行，可以看到 reloadData 按下去之後，方法按照一開始 build 時的順序又重新跑過一遍。先到`numberOfSections`設定 section 數量，緊接 `numberOfRowsInSection`設定每個 section 中的 row 數目。接著用 `cellForRowAt`設定每個 cell 中的內容，最後才到屬於 UITableViewDelegate 的`heightForRowAt`設定行高。
     */
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        backgroundColor = composeColor(red: CGFloat(indexPath.section), green: CGFloat(indexPath.row))
        tableView.reloadData()
        print("reloadData")
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        print("heightForRowAt")
        return 100
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
