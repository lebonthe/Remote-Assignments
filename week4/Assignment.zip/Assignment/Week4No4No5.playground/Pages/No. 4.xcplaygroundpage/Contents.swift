import Foundation

func printPyramid(layers: Int) {
    for i in 0..<layers {
        for _ in 1..<layers - i {
            print(" ", terminator: "")
        }
        for j in 1...(i + 1) * 2 - 1 {
            print("*", terminator: "")
        }
        print("")
    }
}
printPyramid(layers: 5)
//: [Next](@next)
