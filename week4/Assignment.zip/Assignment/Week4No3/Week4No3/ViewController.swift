//
//  ViewController.swift
//  Week4No3
//
//  Created by Min Hu on 2024/2/5.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var stationIDLabel: UILabel!
    @IBOutlet weak var stationNameLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
    }

    func fetchData() {
        guard let url = URL(string: "https://remote-assignment.s3.ap-northeast-1.amazonaws.com/station") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        URLSession.shared.dataTask(with: request) {
            (data, response, error) in
            if let data {
                let decoder = JSONDecoder()
                do {
                    let stationInfo = try decoder.decode(Data.self, from: data)
                    DispatchQueue.main.async {
                        self.stationIDLabel.text = stationInfo.stationID
                        self.stationNameLabel.text = stationInfo.stationName
                        self.addressLabel.text = stationInfo.stationAddress
                    }

                } catch {
                    print(error.localizedDescription)
                }
            }
        }.resume()
    }
}
