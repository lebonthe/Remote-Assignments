//
//  Data.swift
//  Week4No3
//
//  Created by Min Hu on 2024/2/5.
//

import Foundation

struct Data: Decodable {
    let stationID: String
    let stationName: String
    let stationAddress: String
}
